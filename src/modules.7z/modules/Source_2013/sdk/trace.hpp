
/*
 *
 *  Ahh~
 *
 */

#pragma once
class ITraceFilter;
class CTraceListData;
class IEntityEnumerator;
template<typename>
class CUtlVector;
class Vector4D;
class CPhysCollide;
class IEngineTrace {
public:
	// Returns the contents mask + entity at a particular world-space position
	virtual int	GetPointContents(const Vector &vecAbsPosition, IHandleEntity** ppEntity = NULL);

	// Get the point contents, but only test the specific entity. This works
	// on static props and brush models.
	//
	// If the entity isn't a static prop or a brush model, it returns CONTENTS_EMPTY and sets
	// bFailed to true if bFailed is non-null.
	virtual int	GetPointContents_Collideable(ICollideable* pCollide, const Vector& vecAbsPosition);

	// Traces a ray against a particular entity
	virtual void ClipRayToEntity(const Ray_t& ray, unsigned int fMask, IHandleEntity* pEnt, trace_t* pTrace);

	// Traces a ray against a particular entity
	virtual void ClipRayToCollideable(const Ray_t& ray, unsigned int fMask, ICollideable* pCollide, trace_t* pTrace);

	// A version that simply accepts a ray (can work as a traceline or tracehull)
	virtual void TraceRay(const Ray_t& ray, unsigned int fMask, ITraceFilter* pTraceFilter, trace_t* pTrace);

	// A version that sets up the leaf and entity lists and allows you to pass those in for collision.
	virtual void SetupLeafAndEntityListRay(const Ray_t& ray, CTraceListData& traceData);
	virtual void SetupLeafAndEntityListBox(const Vector& vecBoxMin, const Vector& vecBoxMax, CTraceListData& traceData);
	virtual void TraceRayAgainstLeafAndEntityList(const Ray_t& ray, CTraceListData& traceData, unsigned int fMask, ITraceFilter* pTraceFilter, trace_t* pTrace);

	// A version that sweeps a collideable through the world
	// abs start + abs end represents the collision origins you want to sweep the collideable through
	// vecAngles represents the collision angles of the collideable during the sweep
	virtual void SweepCollideable(ICollideable* pCollide, const Vector& vecAbsStart, const Vector& vecAbsEnd,
		const Vector& vecAngles, unsigned int fMask, ITraceFilter* pTraceFilter, trace_t* pTrace);
	// Enumerates over all entities along a ray
	// If triggers == true, it enumerates all triggers along a ray
	virtual void EnumerateEntities(const Ray_t& ray, bool triggers, IEntityEnumerator *pEnumerator);
	// Same thing, but enumerate entitys within a box
	virtual void EnumerateEntities(const Vector& vecAbsMins, const Vector &vecAbsMaxs, IEntityEnumerator *pEnumerator);
	// Convert a handle entity to a collideable.  Useful inside enumer
	virtual ICollideable* GetCollideable(IHandleEntity *pEntity);
	// HACKHACK: Temp for performance measurments
	virtual int GetStatByIndex(int index, bool bClear);


	//finds brushes in an AABB, prone to some false positives
	virtual void GetBrushesInAABB(const Vector &vMins, const Vector &vMaxs, CUtlVector<int> *pOutput, int iContentsMask = 0xFFFFFFFF);

	//Creates a CPhysCollide out of all displacements wholly or partially contained in the specified AABB
	virtual CPhysCollide* GetCollidableFromDisplacementsInAABB(const Vector& vMins, const Vector& vMaxs);

	//retrieve brush planes and contents, returns true if data is being returned in the output pointers, false if the brush doesn't exist
	virtual bool GetBrushInfo(int iBrush, CUtlVector<Vector4D>* pPlanesOut, int* pContentsOut );

	virtual bool PointOutsideWorld(const Vector& ptTest); //Tests a point to see if it's outside any playable area

	// Walks bsp to find the leaf containing the specified point
	virtual int GetLeafContainingPoint(const Vector& ptTest);
};
