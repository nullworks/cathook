 
/*
 *
 *	Header for world to screen framework interface
 *
 */

namespace modules { namespace source { namespace wts {

void Init();

}}}