
/*
 * sdk.h
 *
 *  Created on: Dec 5, 2016
 *      Author: nullifiedcat
 */

/*
 *
 *	This source sdk was modified to suit the needs of cathook.
 *	Please respect cathook and valves licences.
 *
 */

#pragma once

// Multiplatform fixes

// linux
#if defined(__linux__)
#ifdef _GLIBCXX_USE_CXX11_ABI
#undef _GLIBCXX_USE_CXX11_ABI
#endif
#define _GLIBCXX_USE_CXX11_ABI 0
#define _POSIX 1
#define RAD_TELEMETRY_DISABLED 1
#define LINUX 1
#define USE_SDL 1
#define _LINUX 1
#define POSIX 1
#define GNUC 1
#define NO_MALLOC_OVERRIDE 1
// Windows
#elif defined(_WIN32)
//#define GNUC 1
// We define this to trick the source engine that we are using msc
#define _MSC_VER 2000
#define RAD_TELEMETRY_DISABLED 1
//#undef __GNUC__
#undef POSIX
#endif

// To fix cathook from messing with our sdk. This is cathook specific
#undef min
#undef max

#include "public/client_class.h"
#include "public/icliententity.h"
#include "public/icliententitylist.h"
#include "public/cdll_int.h"
#include "public/inetchannelinfo.h"
#include "public/gametrace.h"
#include "public/engine/IEngineTrace.h"
#include "public/materialsystem/imaterialvar.h"
#include "public/globalvars_base.h"
#include "public/materialsystem/itexture.h"
#include "public/engine/ivmodelinfo.h"
#include "public/inputsystem/iinputsystem.h"
#include "public/mathlib/vector.h"
#include "public/icvar.h"
#include "public/Color.h"
#include "public/cmodel.h"
#include "public/igameevents.h"
#include "public/iclient.h"
#include "public/inetchannel.h"
#include "public/ivrenderview.h"
#include "public/tier1/iconvar.h"
#include "public/tier1/convar.h"
#include "public/studio.h"
#include "public/vgui/ISurface.h"
#include "public/vgui/IPanel.h"
#include "public/mathlib/vmatrix.h"
#include "public/inetmessage.h"
#include "public/iclient.h"
#include "public/iserver.h"
#include "public/view_shared.h"
#include "public/tier1/KeyValues.h"
#include "public/tier1/checksum_md5.h"
#include "public/basehandle.h"
#include "public/iachievementmgr.h"
#include "public/VGuiMatSurface/IMatSystemSurface.h"
#include "public/steam/isteamuser.h"
#include "public/steam/steam_api.h"
#include "public/vgui/Cursor.h"
#include "public/engine/ivdebugoverlay.h"
#include "public/iprediction.h"
#include "public/engine/ICollideable.h"
#include "public/tier0/icommandline.h"
#include "game/shared/usercmd.h"
#include "public/edict.h" // CGlobalVars
#include "game/server/playerinfomanager.h" // CPlayerInfoManager


#include "cathook_sdk/TFGCClientSystem.hpp"
#include "cathook_sdk/in_buttons.h"
//#include "cathook/imaterialsystemfixed.h"
#include "cathook_sdk/ScreenSpaceEffects.h"
#include "cathook_sdk/iinput.h"
#include "cathook_sdk/igamemovement.h"
//#include "cathook/HUD.h"

// To fix the sdk messing with our stuff. This is cathook specific
#undef min
#undef max
