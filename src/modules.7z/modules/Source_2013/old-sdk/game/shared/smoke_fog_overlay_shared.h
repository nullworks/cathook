//========= Copyright Valve Corporation, All rights reserved. ============//

#ifndef SMOKE_FOG_OVERLAY_SHARED_H
#define SMOKE_FOG_OVERLAY_SHARED_H


#define SMOKEGRENADE_PARTICLERADIUS	80
#define SMOKEPARTICLE_OVERLAP		20
#define SMOKEPARTICLE_SIZE			80


#endif


