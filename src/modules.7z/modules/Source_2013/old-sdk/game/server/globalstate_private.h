//========= Copyright Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================//

#ifndef GLOBALSTATE_PRIVATE_H
#define GLOBALSTATE_PRIVATE_H
#ifdef _WIN32
#pragma once
#endif


#endif // GLOBALSTATE_PRIVATE_H
