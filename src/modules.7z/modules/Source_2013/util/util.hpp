
/*
 *  Util init header
 *
 */

namespace modules::source::util {

void Init();

}
