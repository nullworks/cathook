
/*
 *
 *	Valve surface drawing header file.
 *	Use the init function to load this!
 *
 */

#pragma once

#if defined(CATHOOK_GFX_SURFACE)

namespace modules::source::valvesurface {

void Init();

}

#endif
