
/*
 *
 *	Helpers for math conversion between the framework and the module
 *
 */

#pragma once
#include "../sdk/sdk.hpp" // Vector()
#include "../../../util/mathlib.hpp"  // CatVector()

inline CatVector ToCatVector(Vector input) {
	return CatVector(input.x, input.y, input.z);
}

inline Vector ToVector(CatVector input) {
	return Vector(input.x, input.y, input.z);
}
