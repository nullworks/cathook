
/*
 *
 * CVARRRRRSSSSSSSSSSSS
 *
 */

#pragma once

#include <cassert>
#include <string.h>

//-----------------------------------------------------------------------------
// Forward declarations
//-----------------------------------------------------------------------------
class IConVar;

//-----------------------------------------------------------------------------
// Command tokenizer
//-----------------------------------------------------------------------------
class characterset_t;
class CCommand {
public:
	bool Tokenize( const char *pCommand, characterset_t *pBreakSet = NULL );
	void Reset();

	int ArgC() const;
	const char **ArgV() const;
	const char *ArgS() const;					// All args that occur after the 0th arg, in string form
	const char *GetCommandString() const;		// The entire command in string form, including the 0th arg
	const char *operator[]( int nIndex ) const;	// Gets at arguments
	const char *Arg( int nIndex ) const;		// Gets at arguments

	// Helper functions to parse arguments to commands.
	const char* FindArg( const char *pName ) const;
	int FindArgInt( const char *pName, int nDefaultVal ) const;

	static int MaxCommandLength();
	static characterset_t* DefaultBreakSet();

private:
	enum {
		COMMAND_MAX_ARGC = 64,
		COMMAND_MAX_LENGTH = 512,
	};

	int		m_nArgc;
	int		m_nArgv0Size;
	char	m_pArgSBuffer[ COMMAND_MAX_LENGTH ];
	char	m_pArgvBuffer[ COMMAND_MAX_LENGTH ];
	const char*	m_ppArgv[ COMMAND_MAX_ARGC ];
};

inline int CCommand::MaxCommandLength() {	return COMMAND_MAX_LENGTH - 1; }
inline int CCommand::ArgC() const {	return m_nArgc; }
inline const char **CCommand::ArgV() const { return m_nArgc ? (const char**)m_ppArgv : NULL; }
inline const char *CCommand::ArgS() const {	return m_nArgv0Size ? &m_pArgSBuffer[m_nArgv0Size] : ""; }
inline const char *CCommand::GetCommandString() const {	return m_nArgc ? m_pArgSBuffer : ""; }
inline const char *CCommand::Arg( int nIndex ) const {
	// FIXME: Many command handlers appear to not be particularly careful
	// about checking for valid argc range. For now, we're going to
	// do the extra check and return an empty string if it's out of range
	if ( nIndex < 0 || nIndex >= m_nArgc )
		return "";
	return m_ppArgv[nIndex];
}
inline const char *CCommand::operator[]( int nIndex ) const {	return Arg( nIndex ); }

//-----------------------------------------------------------------------------
// ConVar flags
//-----------------------------------------------------------------------------
// The default, no flags at all
#define FCVAR_NONE				0

// Command to ConVars and ConCommands
// ConVar Systems
#define FCVAR_UNREGISTERED		(1<<0)	// If this is set, don't add to linked list, etc.
#define FCVAR_DEVELOPMENTONLY	(1<<1)	// Hidden in released products. Flag is removed automatically if ALLOW_DEVELOPMENT_CVARS is defined.
#define FCVAR_GAMEDLL			(1<<2)	// defined by the game DLL
#define FCVAR_CLIENTDLL			(1<<3)  // defined by the client DLL
#define FCVAR_HIDDEN			(1<<4)	// Hidden. Doesn't appear in find or autocomplete. Like DEVELOPMENTONLY, but can't be compiled out.

// ConVar only
#define FCVAR_PROTECTED			(1<<5)  // It's a server cvar, but we don't send the data since it's a password, etc.  Sends 1 if it's not bland/zero, 0 otherwise as value
#define FCVAR_SPONLY			(1<<6)  // This cvar cannot be changed by clients connected to a multiplayer server.
#define	FCVAR_ARCHIVE			(1<<7)	// set to cause it to be saved to vars.rc
#define	FCVAR_NOTIFY			(1<<8)	// notifies players when changed
#define	FCVAR_USERINFO			(1<<9)	// changes the client's info string
#define FCVAR_CHEAT				(1<<14) // Only useable in singleplayer / debug / multiplayer & sv_cheats

#define FCVAR_PRINTABLEONLY		(1<<10)  // This cvar's string cannot contain unprintable characters ( e.g., used for player name etc ).
#define FCVAR_UNLOGGED			(1<<11)  // If this is a FCVAR_SERVER, don't log changes to the log file / console if we are creating a log
#define FCVAR_NEVER_AS_STRING	(1<<12)  // never try to print that cvar

// It's a ConVar that's shared between the client and the server.
// At signon, the values of all such ConVars are sent from the server to the client (skipped for local
//  client, of course )
// If a change is requested it must come from the console (i.e., no remote client changes)
// If a value is changed while a server is active, it's replicated to all connected clients
#define FCVAR_REPLICATED		(1<<13)	// server setting enforced on clients, TODO rename to FCAR_SERVER at some time
#define FCVAR_DEMO				(1<<16)  // record this cvar when starting a demo file
#define FCVAR_DONTRECORD		(1<<17)  // don't record these command in demofiles
#define FCVAR_RELOAD_MATERIALS	(1<<20)	// If this cvar changes, it forces a material reload
#define FCVAR_RELOAD_TEXTURES	(1<<21)	// If this cvar changes, if forces a texture reload

#define FCVAR_NOT_CONNECTED		(1<<22)	// cvar cannot be changed by a client that is connected to a server
#define FCVAR_MATERIAL_SYSTEM_THREAD (1<<23)	// Indicates this cvar is read from the material system thread
#define FCVAR_ARCHIVE_XBOX		(1<<24) // cvar written to config.cfg on the Xbox

#define FCVAR_ACCESSIBLE_FROM_THREADS	(1<<25)	// used as a debugging tool necessary to check material system thread convars

#define FCVAR_SERVER_CAN_EXECUTE	(1<<28)// the server is allowed to execute this command on clients via ClientCommand/NET_StringCmd/CBaseClientState::ProcessStringCmd.
#define FCVAR_SERVER_CANNOT_QUERY	(1<<29)// If this is set, then the server is not allowed to query this cvar's value (via IServerPluginHelpers::StartQueryCvarValue).
#define FCVAR_CLIENTCMD_CAN_EXECUTE	(1<<30)	// IVEngineClient::ClientCmd is allowed to execute this command.
											// Note: IVEngineClient::ClientCmd_Unrestricted can run any client command.

// #define FCVAR_AVAILABLE			(1<<15)
// #define FCVAR_AVAILABLE			(1<<18)
// #define FCVAR_AVAILABLE			(1<<19)
// #define FCVAR_AVAILABLE			(1<<20)
// #define FCVAR_AVAILABLE			(1<<21)
// #define FCVAR_AVAILABLE			(1<<23)
// #define FCVAR_AVAILABLE			(1<<26)
// #define FCVAR_AVAILABLE			(1<<27)
// #define FCVAR_AVAILABLE			(1<<31)

#define FCVAR_MATERIAL_THREAD_MASK ( FCVAR_RELOAD_MATERIALS | FCVAR_RELOAD_TEXTURES | FCVAR_MATERIAL_SYSTEM_THREAD )

//-----------------------------------------------------------------------------
// Called when a ConVar changes value
// NOTE: For FCVAR_NEVER_AS_STRING ConVars, pOldValue == NULL
//-----------------------------------------------------------------------------
typedef void ( *FnChangeCallback_t )( IConVar *var, const char *pOldValue, float flOldValue );


//-----------------------------------------------------------------------------
// Abstract interface for ConVars
//-----------------------------------------------------------------------------
class IConVar {
public:
	// Value set
	virtual void SetValue( const char *pValue ) = 0;
	virtual void SetValue( float flValue ) = 0;
	virtual void SetValue( int nValue ) = 0;

	// Return name of command
	virtual const char *GetName( void ) const = 0;

	// Accessors.. not as efficient as using GetState()/GetInfo()
	// if you call these methods multiple times on the same IConVar
	virtual bool IsFlagSet( int nFlag ) const = 0;
};

//-----------------------------------------------------------------------------
// Called when a ConCommand needs to execute
//-----------------------------------------------------------------------------
typedef void ( *FnCommandCallbackVoid_t )( void );
class CCommand;
typedef void ( *FnCommandCallback_t )( const CCommand &command );

#define COMMAND_COMPLETION_MAXITEMS		64
#define COMMAND_COMPLETION_ITEM_LENGTH	64

//-----------------------------------------------------------------------------
// Returns 0 to COMMAND_COMPLETION_MAXITEMS worth of completion strings
//-----------------------------------------------------------------------------
typedef int  ( *FnCommandCompletionCallback )( const char *partial, char commands[ COMMAND_COMPLETION_MAXITEMS ][ COMMAND_COMPLETION_ITEM_LENGTH ] );


//-----------------------------------------------------------------------------
// Interface version
//-----------------------------------------------------------------------------
class ICommandCallback {
public:
	virtual void CommandCallback( const CCommand &command ) = 0;
};
class CUtlString;
class ICommandCompletionCallback {
public:
	virtual int  CommandCompletionCallback( const char *pPartial, CUtlVector< CUtlString > &commands ) = 0;
};

//-----------------------------------------------------------------------------
// Purpose: The base console invoked command/cvar interface
//-----------------------------------------------------------------------------
class IConCommandBaseAccessor;
class CVarDLLIdentifier_t;
class ConCommandBase {
	friend class CCvar;
	friend class ConVar;
	friend class ConCommand;
	friend void ConVar_Register( int nCVarFlag, IConCommandBaseAccessor *pAccessor );
	friend void ConVar_PublishToVXConsole();

	// FIXME: Remove when ConVar changes are done
	friend class CDefaultCvar;

public:
								ConCommandBase( void );
								ConCommandBase( const char *pName, const char *pHelpString = 0,
									int flags = 0 );

	virtual						~ConCommandBase( void );

	virtual	bool				IsCommand( void ) const;

	// Check flag
	virtual bool				IsFlagSet( int flag ) const;
	// Set flag
	virtual void				AddFlags( int flags );

	// Return name of cvar
	virtual const char			*GetName( void ) const;

	// Return help text for cvar
	virtual const char			*GetHelpText( void ) const;

	// Deal with next pointer
	const ConCommandBase		*GetNext( void ) const;
	ConCommandBase				*GetNext( void );

	virtual bool				IsRegistered( void ) const;

	// Returns the DLL identifier
	virtual CVarDLLIdentifier_t	GetDLLIdentifier() const;

protected:
	virtual void				CreateBase( const char *pName, const char *pHelpString = 0,
									int flags = 0 );

	// Used internally by OneTimeInit to initialize/shutdown
	virtual void				Init();
	void						Shutdown();

	// Internal copy routine ( uses new operator from correct module )
	char						*CopyString( const char *from );

private:
	// Next ConVar in chain
	// Prior to register, it points to the next convar in the DLL.
	// Once registered, though, m_pNext is reset to point to the next
	// convar in the global list
	ConCommandBase				*m_pNext;

	// Has the cvar been added to the global list?
	bool						m_bRegistered;

	// Static data
	const char 					*m_pszName;
	const char 					*m_pszHelpString;

	// ConVar flags
	int							m_nFlags;

protected:
	// ConVars add themselves to this list for the executable.
	// Then ConVar_Register runs through  all the console variables
	// and registers them into a global list stored in vstdlib.dll
	static ConCommandBase		*s_pConCommandBases;

	// ConVars in this executable use this 'global' to access values.
	static IConCommandBaseAccessor	*s_pAccessor;
};

 //-----------------------------------------------------------------------------
 // Purpose: The console invoked command
 //-----------------------------------------------------------------------------
 class ConCommand : public ConCommandBase {
 friend class CCvar;

 public:
 	typedef ConCommandBase BaseClass;

 	ConCommand( const char *pName, FnCommandCallbackVoid_t callback,
 		const char *pHelpString = 0, int flags = 0, FnCommandCompletionCallback completionFunc = 0 );
 	ConCommand( const char *pName, FnCommandCallback_t callback,
 		const char *pHelpString = 0, int flags = 0, FnCommandCompletionCallback completionFunc = 0 );
 	ConCommand( const char *pName, ICommandCallback *pCallback,
 		const char *pHelpString = 0, int flags = 0, ICommandCompletionCallback *pCommandCompletionCallback = 0 );

 	virtual ~ConCommand( void );

 	virtual	bool IsCommand( void ) const;

 	virtual int AutoCompleteSuggest( const char *partial, CUtlVector< CUtlString > &commands );

 	virtual bool CanAutoComplete( void );

 	// Invoke the function
 	virtual void Dispatch( const CCommand &command );

 private:
 	// NOTE: To maintain backward compat, we have to be very careful:
 	// All public virtual methods must appear in the same order always
 	// since engine code will be calling into this code, which *does not match*
 	// in the mod code; it's using slightly different, but compatible versions
 	// of this class. Also: Be very careful about adding new fields to this class.
 	// Those fields will not exist in the version of this class that is instanced
 	// in mod code.

 	// Call this function when executing the command
 	union
 	{
 		FnCommandCallbackVoid_t m_fnCommandCallbackV1;
 		FnCommandCallback_t m_fnCommandCallback;
 		ICommandCallback *m_pCommandCallback;
 	};

 	union
 	{
 		FnCommandCompletionCallback	m_fnCompletionCallback;
 		ICommandCompletionCallback *m_pCommandCompletionCallback;
 	};

 	bool m_bHasCompletionCallback : 1;
 	bool m_bUsingNewCommandCallback : 1;
 	bool m_bUsingCommandCallbackInterface : 1;
 };


 //-----------------------------------------------------------------------------
 // Purpose: A console variable
 //-----------------------------------------------------------------------------
 class ConVar : public ConCommandBase, public IConVar {
 friend class CCvar;
 friend class ConVarRef;

 public:
 	typedef ConCommandBase BaseClass;

 	ConVar(const char *pName, const char *pDefaultValue, int flags = 0);
  ConVar(const char *pName, const char *pDefaultValue, int flags,
 				 const char *pHelpString );
 	ConVar(const char *pName, const char *pDefaultValue, int flags,
 				 const char *pHelpString, bool bMin, float fMin, bool bMax, float fMax);
 	ConVar(const char *pName, const char *pDefaultValue, int flags,
 				 const char *pHelpString, FnChangeCallback_t callback);
 	ConVar(const char *pName, const char *pDefaultValue, int flags,
 				 const char *pHelpString, bool bMin, float fMin, bool bMax, float fMax,
 				 FnChangeCallback_t callback);

 	virtual						  ~ConVar( void );
 	virtual bool				IsFlagSet( int flag ) const;
 	virtual const char*	GetHelpText( void ) const;
 	virtual bool				IsRegistered( void ) const;
 	virtual const char* GetName( void ) const;
 	virtual void				AddFlags( int flags );
 	virtual	bool				IsCommand( void ) const;

 	// Install a change callback (there shouldn't already be one....)
 	void InstallChangeCallback( FnChangeCallback_t callback );

 	// Retrieve value
  inline float GetFloat() const {
   return m_pParent->m_fValue;
  }
  inline int GetInt() const {
    return m_pParent->m_nValue;
  }
 	inline bool GetBool() const {return !!GetInt();}
  inline const char* GetString() const {
   if (m_nFlags & FCVAR_NEVER_AS_STRING)
     return "FCVAR_NEVER_AS_STRING";
   return (m_pParent->m_pszString) ? m_pParent->m_pszString : "";
  }

 	// Any function that allocates/frees memory needs to be virtual or else you'll have crashes
 	//  from alloc/free across dll/exe boundaries.

 	// These just call into the IConCommandBaseAccessor to check flags and set the var (which ends up calling InternalSetValue).
 	virtual void				SetValue( const char *value );
 	virtual void				SetValue( float value );
 	virtual void				SetValue( int value );

 	// Reset to default value
 	void						Revert( void );

 	// True if it has a min/max setting
 	bool						GetMin( float& minVal ) const;
 	bool						GetMax( float& maxVal ) const;
 	const char					*GetDefault( void ) const;
 	void						SetDefault( const char *pszDefault );

 private:
 	// Called by CCvar when the value of a var is changing.
 	virtual void				InternalSetValue(const char *value);
 	// For CVARs marked FCVAR_NEVER_AS_STRING
 	virtual void				InternalSetFloatValue( float fNewValue );
 	virtual void				InternalSetIntValue( int nValue );

 	virtual bool				ClampValue( float& value );
 	virtual void				ChangeStringValue( const char *tempVal, float flOldValue );

 	virtual void				Create( const char *pName, const char *pDefaultValue, int flags = 0,
 									const char *pHelpString = 0, bool bMin = false, float fMin = 0.0,
 									bool bMax = false, float fMax = false, FnChangeCallback_t callback = 0 );

 	// Used internally by OneTimeInit to initialize.
 	virtual void				Init();
 	int GetFlags() { return m_pParent->m_nFlags; }
 private:

 	// This either points to "this" or it points to the original declaration of a ConVar.
 	// This allows ConVars to exist in separate modules, and they all use the first one to be declared.
 	// m_pParent->m_pParent must equal m_pParent (ie: m_pParent must be the root, or original, ConVar).
 	ConVar						*m_pParent;

 	// Static data
 	const char					*m_pszDefaultValue;

 	// Value
 	// Dynamically allocated
 	char						*m_pszString;
 	int							m_StringLength;

 	// Values
 	float						m_fValue;
 	int							m_nValue;

 	// Min/Max values
 	bool						m_bHasMin;
 	float						m_fMinVal;
 	bool						m_bHasMax;
 	float						m_fMaxVal;

 	// Call this function when ConVar changes
 	FnChangeCallback_t			m_fnChangeCallback;
 };

 ConVar::ConVar( const char *pName, const char *pDefaultValue, int flags /* = 0 */ )
 {
 	Create( pName, pDefaultValue, flags );
 }

 ConVar::ConVar( const char *pName, const char *pDefaultValue, int flags, const char *pHelpString )
 {
 	Create( pName, pDefaultValue, flags, pHelpString );
 }

 ConVar::ConVar( const char *pName, const char *pDefaultValue, int flags, const char *pHelpString, bool bMin, float fMin, bool bMax, float fMax )
 {
 	Create( pName, pDefaultValue, flags, pHelpString, bMin, fMin, bMax, fMax );
 }

 ConVar::ConVar( const char *pName, const char *pDefaultValue, int flags, const char *pHelpString, FnChangeCallback_t callback )
 {
 	Create( pName, pDefaultValue, flags, pHelpString, false, 0.0, false, 0.0, callback );
 }

 ConVar::ConVar( const char *pName, const char *pDefaultValue, int flags, const char *pHelpString, bool bMin, float fMin, bool bMax, float fMax, FnChangeCallback_t callback )
 {
 	Create( pName, pDefaultValue, flags, pHelpString, bMin, fMin, bMax, fMax, callback );
 }


 //-----------------------------------------------------------------------------
 // Destructor
 //-----------------------------------------------------------------------------
 ConVar::~ConVar( void )
 {
 	if ( m_pszString )
 	{
 		delete[] m_pszString;
 		m_pszString = NULL;
 	}
 }


 //-----------------------------------------------------------------------------
 // Install a change callback (there shouldn't already be one....)
 //-----------------------------------------------------------------------------
 void ConVar::InstallChangeCallback( FnChangeCallback_t callback )
 {
 	assert( !m_pParent->m_fnChangeCallback || !callback );
 	m_pParent->m_fnChangeCallback = callback;

 	if ( m_pParent->m_fnChangeCallback )
 	{
 		// Call it immediately to set the initial value...
 		m_pParent->m_fnChangeCallback( this, m_pszString, m_fValue );
 	}
 }

 bool ConVar::IsFlagSet( int flag ) const
 {
 	return ( flag & m_pParent->m_nFlags ) ? true : false;
 }

 const char *ConVar::GetHelpText( void ) const
 {
 	return m_pParent->m_pszHelpString;
 }

 void ConVar::AddFlags( int flags )
 {
 	m_pParent->m_nFlags |= flags;

 #ifdef ALLOW_DEVELOPMENT_CVARS
 	m_pParent->m_nFlags &= ~FCVAR_DEVELOPMENTONLY;
 #endif
 }

 bool ConVar::IsRegistered( void ) const
 {
 	return m_pParent->m_bRegistered;
 }

 const char *ConVar::GetName( void ) const
 {
 	return m_pParent->m_pszName;
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Output : Returns true on success, false on failure.
 //-----------------------------------------------------------------------------
 bool ConVar::IsCommand( void ) const
 {
 	return false;
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  :
 //-----------------------------------------------------------------------------
 void ConVar::Init()
 {
 	BaseClass::Init();
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : *value -
 //-----------------------------------------------------------------------------
 void ConVar::InternalSetValue( const char *value )
 {
 	if ( IsFlagSet( FCVAR_MATERIAL_THREAD_MASK ) )
 	{
 		/*if ( g_pCVar && !g_pCVar->IsMaterialThreadSetAllowed() )
 		{
 			g_pCVar->QueueMaterialThreadSetValue( this, value );
 			return;
 		}*/
 	}

 	float fNewValue;
 	char  tempVal[ 32 ];
 	char  *val;

 	assert(m_pParent == this); // Only valid for root convars.

 	float flOldValue = m_fValue;

 	val = (char *)value;
 	if ( !value )
 		fNewValue = 0.0f;
 	else
 		fNewValue = ( float )atof( value );

 	if ( ClampValue( fNewValue ) )
 	{
 		//Q_snprintf( tempVal,sizeof(tempVal), "%f", fNewValue );
 		val = tempVal;
 	}

 	// Redetermine value
 	m_fValue		= fNewValue;
 	m_nValue		= ( int )( fNewValue );

 	if ( !( m_nFlags & FCVAR_NEVER_AS_STRING ) )
 	{
 		ChangeStringValue( val, flOldValue );
 	}
 }
 #define ALIGN_VALUE( val, alignment ) ( ( val + alignment - 1 ) & ~( alignment - 1 ) ) //  need macro for constant expression
#define stackalloc( _size )		alloca( ALIGN_VALUE( _size, 16 ) )
#define  stackfree( _p )			0
 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : *tempVal -
 //-----------------------------------------------------------------------------
 void ConVar::ChangeStringValue( const char *tempVal, float flOldValue )
 {
 	assert( !( m_nFlags & FCVAR_NEVER_AS_STRING ) );

  	char* pszOldValue = (char*)stackalloc( m_StringLength );
 	memcpy( pszOldValue, m_pszString, m_StringLength );

 	if ( tempVal )
 	{
 		int len = strlen(tempVal) + 1;

 		if ( len > m_StringLength)
 		{
 			if (m_pszString)
 			{
 				delete[] m_pszString;
 			}

 			m_pszString	= new char[len];
 			m_StringLength = len;
 		}

 		memcpy( m_pszString, tempVal, len );
 	}
 	else
 	{
 		*m_pszString = 0;
 	}

 	// If nothing has changed, don't do the callbacks.
 	if (strcmp(pszOldValue, m_pszString) != 0)
 	{
 		// Invoke any necessary callback function
 		if ( m_fnChangeCallback )
 		{
 			m_fnChangeCallback( this, pszOldValue, flOldValue );
 		}

     // Commented due to crashes
 		//g_pCVar->CallGlobalChangeCallbacks( this, pszOldValue, flOldValue );
 	}

 	stackfree( pszOldValue );
 }

 //-----------------------------------------------------------------------------
 // Purpose: Check whether to clamp and then perform clamp
 // Input  : value -
 // Output : Returns true if value changed
 //-----------------------------------------------------------------------------
 bool ConVar::ClampValue( float& value )
 {
 	if ( m_bHasMin && ( value < m_fMinVal ) )
 	{
 		value = m_fMinVal;
 		return true;
 	}

 	if ( m_bHasMax && ( value > m_fMaxVal ) )
 	{
 		value = m_fMaxVal;
 		return true;
 	}

 	return false;
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : *value -
 //-----------------------------------------------------------------------------
 void ConVar::InternalSetFloatValue( float fNewValue )
 {
 	if ( fNewValue == m_fValue )
 		return;

 	if ( IsFlagSet( FCVAR_MATERIAL_THREAD_MASK ) )
 	{
 		/*if ( g_pCVar && !g_pCVar->IsMaterialThreadSetAllowed() )
 		{
 			g_pCVar->QueueMaterialThreadSetValue( this, fNewValue );
 			return;
 		}*/
 	}

 	assert( m_pParent == this ); // Only valid for root convars.

 	// Check bounds
 	ClampValue( fNewValue );

 	// Redetermine value
 	float flOldValue = m_fValue;
 	m_fValue		= fNewValue;
 	m_nValue		= ( int )m_fValue;

 	if ( !( m_nFlags & FCVAR_NEVER_AS_STRING ) )
 	{
 		char tempVal[ 32 ];
 	 snprintf( tempVal, sizeof( tempVal), "%f", m_fValue );
 		ChangeStringValue( tempVal, flOldValue );
 	}
 	else
 	{
 		assert( !m_fnChangeCallback );
 	}
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : *value -
 //-----------------------------------------------------------------------------
 void ConVar::InternalSetIntValue( int nValue )
 {
 	if ( nValue == m_nValue )
 		return;

 	if ( IsFlagSet( FCVAR_MATERIAL_THREAD_MASK ) )
 	{
 		/*if ( g_pCVar && !g_pCVar->IsMaterialThreadSetAllowed() )
 		{
 			g_pCVar->QueueMaterialThreadSetValue( this, nValue );
 			return;
 		}*/
 	}

 	assert( m_pParent == this ); // Only valid for root convars.

 	float fValue = (float)nValue;
 	if ( ClampValue( fValue ) )
 	{
 		nValue = ( int )( fValue );
 	}

 	// Redetermine value
 	float flOldValue = m_fValue;
 	m_fValue		= fValue;
 	m_nValue		= nValue;

 	if ( !( m_nFlags & FCVAR_NEVER_AS_STRING ) )
 	{
 		char tempVal[ 32 ];
 		snprintf( tempVal, sizeof( tempVal ), "%d", m_nValue );
 		ChangeStringValue( tempVal, flOldValue );
 	}
 	else
 	{
 		assert( !m_fnChangeCallback );
 	}
 }

 //-----------------------------------------------------------------------------
 // Purpose: Private creation
 //-----------------------------------------------------------------------------
 void ConVar::Create( const char *pName, const char *pDefaultValue, int flags /*= 0*/,
 	const char *pHelpString /*= NULL*/, bool bMin /*= false*/, float fMin /*= 0.0*/,
 	bool bMax /*= false*/, float fMax /*= false*/, FnChangeCallback_t callback /*= NULL*/ )
 {
 	m_pParent = this;

 	// Name should be static data
 	SetDefault( pDefaultValue );

 	m_StringLength = strlen( m_pszDefaultValue ) + 1;
 	m_pszString = new char[m_StringLength];
 	memcpy( m_pszString, m_pszDefaultValue, m_StringLength );

 	m_bHasMin = bMin;
 	m_fMinVal = fMin;
 	m_bHasMax = bMax;
 	m_fMaxVal = fMax;

 	m_fnChangeCallback = callback;

 	m_fValue = ( float )atof( m_pszString );
 	m_nValue = atoi( m_pszString ); // dont convert from float to int and lose bits

 	// Bounds Check, should never happen, if it does, no big deal
 	if ( m_bHasMin && ( m_fValue < m_fMinVal ) )
 	{
 		assert( 0 );
 	}

 	if ( m_bHasMax && ( m_fValue > m_fMaxVal ) )
 	{
 		assert( 0 );
 	}

 	BaseClass::CreateBase( pName, pHelpString, flags );
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : *value -
 //-----------------------------------------------------------------------------
 void ConVar::SetValue(const char *value)
 {
 	ConVar *var = ( ConVar * )m_pParent;
 	var->InternalSetValue( value );
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : value -
 //-----------------------------------------------------------------------------
 void ConVar::SetValue( float value )
 {
 	ConVar *var = ( ConVar * )m_pParent;
 	var->InternalSetFloatValue( value );
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : value -
 //-----------------------------------------------------------------------------
 void ConVar::SetValue( int value ) {
	ConVar *var = ( ConVar * )m_pParent;
 	var->InternalSetIntValue( value );
 }

 //-----------------------------------------------------------------------------
 // Purpose: Reset to default value
 //-----------------------------------------------------------------------------
 void ConVar::Revert( void ) {
 	// Force default value again
 	ConVar *var = ( ConVar * )m_pParent;
 	var->SetValue( var->m_pszDefaultValue );
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : minVal -
 // Output : true if there is a min set
 //-----------------------------------------------------------------------------
 bool ConVar::GetMin( float& minVal ) const {
 	minVal = m_pParent->m_fMinVal;
 	return m_pParent->m_bHasMin;
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Input  : maxVal -
 //-----------------------------------------------------------------------------
 bool ConVar::GetMax( float& maxVal ) const {
 	maxVal = m_pParent->m_fMaxVal;
 	return m_pParent->m_bHasMax;
 }

 //-----------------------------------------------------------------------------
 // Purpose:
 // Output : const char
 //-----------------------------------------------------------------------------
 const char *ConVar::GetDefault( void ) const {
 	return m_pParent->m_pszDefaultValue;
 }

 void ConVar::SetDefault( const char *pszDefault ) {
 	m_pszDefaultValue = pszDefault ? pszDefault : "";
 	assert( m_pszDefaultValue );
 }


#ifndef IAppSystem_lel
#define IAppSystem_lel
 class IAppSystem {
 public:
 	// Here's where the app systems get to learn about each other
 	virtual bool Connect( CreateInterfaceFn factory ) = 0;
 	virtual void Disconnect() = 0;

 	// Here's where systems can access other interfaces implemented by this object
 	// Returns NULL if it doesn't implement the requested interface
 	virtual void *QueryInterface( const char *pInterfaceName ) = 0;

 	// Init, shutdown
 	virtual InitReturnVal_t Init() = 0;
 	virtual void Shutdown() = 0;
 };
#endif
 //-----------------------------------------------------------------------------
// Purpose: DLL interface to ConVars/ConCommands
//-----------------------------------------------------------------------------
class IConsoleDisplayFunc;
class Color;
class ICvarQuery;
class ICvar : public IAppSystem {
public:
	// Allocate a unique DLL identifier
	virtual CVarDLLIdentifier_t AllocateDLLIdentifier() = 0;

	// Register, unregister commands
	virtual void			RegisterConCommand( ConCommandBase *pCommandBase ) = 0;
	virtual void			UnregisterConCommand( ConCommandBase *pCommandBase ) = 0;
	virtual void			UnregisterConCommands( CVarDLLIdentifier_t id ) = 0;

	// If there is a +<varname> <value> on the command line, this returns the value.
	// Otherwise, it returns NULL.
	virtual const char*		GetCommandLineValue( const char *pVariableName ) = 0;

	// Try to find the cvar pointer by name
	virtual ConCommandBase *FindCommandBase( const char *name ) = 0;
	virtual const ConCommandBase *FindCommandBase( const char *name ) const = 0;
	virtual ConVar			*FindVar ( const char *var_name ) = 0;
	virtual const ConVar	*FindVar ( const char *var_name ) const = 0;
	virtual ConCommand		*FindCommand( const char *name ) = 0;
	virtual const ConCommand *FindCommand( const char *name ) const = 0;

	// Get first ConCommandBase to allow iteration
	virtual ConCommandBase	*GetCommands( void ) = 0;
	virtual const ConCommandBase *GetCommands( void ) const = 0;

	// Install a global change callback (to be called when any convar changes)
	virtual void			InstallGlobalChangeCallback( FnChangeCallback_t callback ) = 0;
	virtual void			RemoveGlobalChangeCallback( FnChangeCallback_t callback ) = 0;
	virtual void			CallGlobalChangeCallbacks( ConVar *var, const char *pOldString, float flOldValue ) = 0;

	// Install a console printer
	virtual void			InstallConsoleDisplayFunc( IConsoleDisplayFunc* pDisplayFunc ) = 0;
	virtual void			RemoveConsoleDisplayFunc( IConsoleDisplayFunc* pDisplayFunc ) = 0;
	virtual void			ConsoleColorPrintf( const Color& clr, const char* pFormat, ... ) const = 0;
	virtual void			ConsolePrintf(const char* pFormat, ... ) const = 0;
	virtual void			ConsoleDPrintf(const char* pFormat, ... ) const = 0;

	// Reverts cvars which contain a specific flag
	virtual void			RevertFlaggedConVars( int nFlag ) = 0;

	// Method allowing the engine ICvarQuery interface to take over
	// A little hacky, owing to the fact the engine is loaded
	// well after ICVar, so we can't use the standard connect pattern
	virtual void			InstallCVarQuery( ICvarQuery *pQuery ) = 0;

#if defined( _X360 )
	virtual void			PublishToVXConsole( ) = 0;
#endif
	virtual bool			IsMaterialThreadSetAllowed( ) const = 0;
	virtual void			QueueMaterialThreadSetValue( ConVar *pConVar, const char *pValue ) = 0;
	virtual void			QueueMaterialThreadSetValue( ConVar *pConVar, int nValue ) = 0;
	virtual void			QueueMaterialThreadSetValue( ConVar *pConVar, float flValue ) = 0;
	virtual bool			HasQueuedMaterialThreadConVarSets() const = 0;
	virtual int				ProcessQueuedMaterialThreadConVarSets() = 0;

protected:	class ICVarIteratorInternal;
public:
	/// Iteration over all cvars.
	/// (THIS IS A SLOW OPERATION AND YOU SHOULD AVOID IT.)
	/// usage:
	/// { ICVar::Iterator iter(g_pCVar);
	///   for ( iter.SetFirst() ; iter.IsValid() ; iter.Next() )
	///   {
	///       ConCommandBase *cmd = iter.Get();
	///   }
	/// }
	/// The Iterator class actually wraps the internal factory methods
	/// so you don't need to worry about new/delete -- scope takes care
	//  of it.
	/// We need an iterator like this because we can't simply return a
	/// pointer to the internal data type that contains the cvars --
	/// it's a custom, protected class with unusual semantics and is
	/// prone to change.
	class Iterator
	{
	public:
		inline Iterator(ICvar *icvar);
		inline ~Iterator(void);
		inline void		SetFirst( void );
		inline void		Next( void );
		inline bool		IsValid( void );
		inline ConCommandBase *Get( void );
	private:
		ICVarIteratorInternal *m_pIter;
	};

protected:
	// internals for  ICVarIterator
	class ICVarIteratorInternal
	{
	public:
		// warning: delete called on 'ICvar::ICVarIteratorInternal' that is abstract but has non-virtual destructor [-Wdelete-non-virtual-dtor]
		virtual ~ICVarIteratorInternal() {}
		virtual void		SetFirst( void ) = 0;
		virtual void		Next( void ) = 0;
		virtual	bool		IsValid( void ) = 0;
		virtual ConCommandBase *Get( void ) = 0;
	};

	virtual ICVarIteratorInternal	*FactoryInternalIterator( void ) = 0;
	friend class Iterator;
};
