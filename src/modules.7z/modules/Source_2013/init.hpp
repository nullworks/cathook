
namespace modules::source {

// The startup function for the module
void Init();

}
