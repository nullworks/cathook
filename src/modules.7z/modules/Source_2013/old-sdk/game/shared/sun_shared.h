//========= Copyright Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
//=============================================================================//

#ifndef SUN_SHARED_H
#define SUN_SHARED_H
#ifdef _WIN32
#pragma once
#endif

//FIXME: It strikes me that the usefulness of this header file is now diminished

#define MAX_SUN_LAYERS 4

#define	SF_LIGHTGLOW_DIRECTIONAL	(1<<0)
#define	SF_MODULATE_BY_DIRECTION	(1<<1)

#endif // SUN_SHARED_H
