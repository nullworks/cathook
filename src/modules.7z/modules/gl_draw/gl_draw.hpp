
/*
 *
 *  Init for gl draw
 *
 */

namespace modules { namespace gl_draw {

void Init();

}}
