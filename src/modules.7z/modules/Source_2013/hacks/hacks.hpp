
/*
 *
 *	Init stuff for the hacks section of the tf2 module.
 *
 */

namespace modules::source::hacks {

void Init();

}
