
/*
 *
 * maff
 *
 */

#pragma once

#include <cassert>

 class Vector
 {
 public:
 	// Members
  float x, y, z;
 	// Construction/destruction:
 	inline Vector(float _x = 0, float _y = 0, float _z = 0) : x(_x), y(_y), z(_z){}

 	// array access...
 	float operator[](int i) const {
    assert( (i >= 0) && (i < 3) );
    return ((float*)this)[i];
  }
 	float& operator[](int i) {
    assert( (i >= 0) && (i < 3) );
    return ((float*)this)[i];
  }

 	// Base address...
 	float* Base() {return (float*)this;}
 	float const* Base() const {return (const float*)this;}

 	// Initialization methods
  inline void Random(float minVal, float maxVal) {
  	x = minVal + ((float)rand() / 0x7fff) * (maxVal - minVal);
  	y = minVal + ((float)rand() / 0x7fff) * (maxVal - minVal);
  	z = minVal + ((float)rand() / 0x7fff) * (maxVal - minVal);
  }
 	inline void Zero() {x = y = z = 0.0f;} ///< zero out a vector

 	// equality
 	inline bool operator==(const Vector& src) const {
    return (src.x == x) && (src.y == y) && (src.z == z);
  }
 	inline bool operator!=(const Vector& src) const {
    return (src.x != x) || (src.y != y) || (src.z != z);
  }

 	// arithmetic operations
 	inline Vector& operator+=(const Vector &v) {x+=v.x; y+=v.y; z += v.z; return *this;}
 	inline Vector& operator-=(const Vector &v) {x-=v.x; y-=v.y; z -= v.z; return *this;}
 	inline Vector& operator*=(const Vector &v) {x *= v.x; y *= v.y; z *= v.z; return *this;}
 	inline Vector& operator*=(float fl) {x *= fl; y *= fl; z *= fl; return *this;}
 	inline Vector& operator/=(const Vector &v) {x /= v.x;	y /= v.y;	z /= v.z; return *this;}
 	inline Vector& operator/=(float fl) {float oofl = 1.0f / fl; x *= oofl; y *= oofl; z *= oofl; return *this;}
 	inline Vector& operator+=(float fl) {x += fl; y += fl; z += fl; return *this;} ///< broadcast add
 	inline Vector& operator-=(float fl) {x -= fl; y -= fl; z -= fl; return *this;} ///< broadcast sub

  // negate the vector components
 	inline void Negate() {x = -x; y = -y; z = -z;};

 	// Get the vector's magnitude.
 	inline float Length() const;

 	// Get the vector's magnitude squared.
  inline float LengthSqr(void) const {
 		return (x*x + y*y + z*z);
 	}

 	// return true if this vector is (0,0,0) within tolerance
 	inline bool IsZero( float tolerance = 0.01f ) const {
 		return (x > -tolerance && x < tolerance &&
 				y > -tolerance && y < tolerance &&
 				z > -tolerance && z < tolerance);
 	}

 	float	NormalizeInPlace();
 	Vector	Normalized() const;
 	bool	IsLengthGreaterThan( float val ) const;
 	bool	IsLengthLessThan( float val ) const;

 	// check if a vector is within the box defined by two other vectors
  inline bool WithinAABox( Vector const &boxmin, Vector const &boxmax);

 	// Get the distance from this vector to the other one.
 	float	DistTo(const Vector &vOther) const;

 	// Get the distance from this vector to the other one squared.
 	// NJS: note, VC wasn't inlining it correctly in several deeply nested inlines due to being an 'out of line' inline.
 	// may be able to tidy this up after switching to VC7
 	inline float DistToSqr(const Vector &vOther) const {
 		Vector delta;

 		delta.x = x - vOther.x;
 		delta.y = y - vOther.y;
 		delta.z = z - vOther.z;

 		return delta.LengthSqr();
 	}

 	// Copy
 	void	CopyToArray(float* rgfl) const;

 	// Multiply, add, and assign to this (ie: *this = a + b * scalar). This
 	// is about 12% faster than the actual vector equation (because it's done per-component
 	// rather than per-vector).
 	void	MulAdd(const Vector& a, const Vector& b, float scalar);

 	// Dot product.
 	float	Dot(const Vector& vOther) const;

 	// assignment
 	Vector& operator=(const Vector &vOther);

 	// 2d
 	float	Length2D(void) const;
 	float	Length2DSqr(void) const;

 	// arithmetic operations
 	Vector	operator+(const Vector& v) const;
 	Vector	operator-(const Vector& v) const;
 	Vector	operator*(const Vector& v) const;
 	Vector	operator/(const Vector& v) const;
 	Vector	operator*(float fl) const;
 	Vector	operator/(float fl) const;

 	// Cross product between two vectors.
 	Vector	Cross(const Vector &vOther) const;

 	// Returns a vector with the min or max in X, Y, and Z.
 	Vector Min(const Vector &vOther) const;
 	Vector Max(const Vector &vOther) const;
 };
